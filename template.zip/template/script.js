// ===== GLOBAL VARIABLES =====
let currentTemplate = 'modern-pro';
let resumeData = {
    personal: {
        fullName: '',
        jobTitle: '',
        summary: '',
        email: '',
        phone: '',
        location: '',
        linkedin: '',
        profileImage: ''
    },
    experience: [],
    education: [],
    skills: [],
    hobbies: [],
    languages: []
};

// ===== TEMPLATE CONFIGURATIONS =====
const templateConfigs = {
    'modern-pro': {
        name: 'Modern Professional',
        category: 'professional',
        color: '#4a6fa5',
        font: "'Poppins', sans-serif",
        layout: 'two-column',
        hasPhoto: true
    },
    'executive-classic': {
        name: 'Executive Classic',
        category: 'executive',
        color: '#1a2a3a',
        font: "'Roboto', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'creative-minimal': {
        name: 'Creative Minimal',
        category: 'creative minimal',
        color: '#5a67d8',
        font: "'Montserrat', sans-serif",
        layout: 'modern',
        hasPhoto: true
    },
    'academic-scholar': {
        name: 'Academic Scholar',
        category: 'professional',
        color: '#2d6a4f',
        font: "'Roboto', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'modern-compact': {
        name: 'Modern Compact',
        category: 'professional minimal',
        color: '#3a506b',
        font: "'Poppins', sans-serif",
        layout: 'two-column',
        hasPhoto: true
    },
    'bold-statement': {
        name: 'Bold Statement',
        category: 'creative',
        color: '#9d4edd',
        font: "'Montserrat', sans-serif",
        layout: 'creative',
        hasPhoto: true
    },
    'corporate-blue': {
        name: 'Corporate Blue',
        category: 'executive professional',
        color: '#1565c0',
        font: "'Roboto', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'clean-modern': {
        name: 'Clean Modern',
        category: 'minimal',
        color: '#6d6875',
        font: "'Open Sans', sans-serif",
        layout: 'minimal',
        hasPhoto: false
    },
    'tech-innovator': {
        name: 'Tech Innovator',
        category: 'professional creative',
        color: '#ff6b6b',
        font: "'Poppins', sans-serif",
        layout: 'two-column',
        hasPhoto: true
    },
    'elegant-pro': {
        name: 'Elegant Professional',
        category: 'executive',
        color: '#495057',
        font: "'Lato', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'modern-tech': {
        name: 'Modern Tech',
        category: 'professional modern',
        color: '#2563eb',
        font: "'Inter', sans-serif",
        layout: 'two-column',
        hasPhoto: true
    },
    'creative-portfolio': {
        name: 'Creative Portfolio',
        category: 'creative',
        color: '#ec4899',
        font: "'Playfair Display', serif",
        layout: 'creative',
        hasPhoto: true
    },
    'corporate-minimal': {
        name: 'Corporate Minimal',
        category: 'executive minimal',
        color: '#0f172a',
        font: "'Roboto', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'academic-elegant': {
        name: 'Academic Elegant',
        category: 'professional',
        color: '#059669',
        font: "'Merriweather', serif",
        layout: 'single',
        hasPhoto: false
    },
    'bold-modern': {
        name: 'Bold Modern',
        category: 'creative modern',
        color: '#7c3aed',
        font: "'Montserrat', sans-serif",
        layout: 'creative',
        hasPhoto: true
    },
    'simple-clean': {
        name: 'Simple Clean',
        category: 'minimal',
        color: '#475569',
        font: "'Open Sans', sans-serif",
        layout: 'minimal',
        hasPhoto: false
    },
    'executive-bold': {
        name: 'Executive Bold',
        category: 'executive',
        color: '#1e40af',
        font: "'Roboto', sans-serif",
        layout: 'single',
        hasPhoto: false
    },
    'modern-creative': {
        name: 'Modern Creative',
        category: 'creative modern',
        color: '#3b82f6',
        font: "'Poppins', sans-serif",
        layout: 'creative',
        hasPhoto: true
    }
};

// ===== TEMPLATE GENERATION WITH DIFFERENT LAYOUTS =====
function generateTemplates() {
    const templatesGrid = document.getElementById('templatesGrid');
    templatesGrid.innerHTML = '';
    
    for (const [id, config] of Object.entries(templateConfigs)) {
        const templateCard = document.createElement('div');
        templateCard.className = 'template-card';
        templateCard.setAttribute('data-template-id', id);
        templateCard.setAttribute('data-filter', config.category);
        
        const gradientColors = {
            'modern-pro': 'linear-gradient(135deg, #2c3e50, #4a6491)',
            'executive-classic': 'linear-gradient(135deg, #1a2a3a, #2d3e50)',
            'creative-minimal': 'linear-gradient(135deg, #5a67d8, #805ad5)',
            'academic-scholar': 'linear-gradient(135deg, #2d6a4f, #40916c)',
            'modern-compact': 'linear-gradient(135deg, #3a506b, #5bc0be)',
            'bold-statement': 'linear-gradient(135deg, #9d4edd, #560bad)',
            'corporate-blue': 'linear-gradient(135deg, #1565c0, #0d47a1)',
            'clean-modern': 'linear-gradient(135deg, #6d6875, #b5838d)',
            'tech-innovator': 'linear-gradient(135deg, #ff6b6b, #ff8e53)',
            'elegant-pro': 'linear-gradient(135deg, #495057, #6c757d)',
            'modern-tech': 'linear-gradient(135deg, #1e40af, #3b82f6)',
            'creative-portfolio': 'linear-gradient(135deg, #db2777, #ec4899)',
            'corporate-minimal': 'linear-gradient(135deg, #0f172a, #334155)',
            'academic-elegant': 'linear-gradient(135deg, #047857, #059669)',
            'bold-modern': 'linear-gradient(135deg, #6d28d9, #7c3aed)',
            'simple-clean': 'linear-gradient(135deg, #475569, #64748b)',
            'executive-bold': 'linear-gradient(135deg, #1e3a8a, #1e40af)',
            'modern-creative': 'linear-gradient(135deg, #2563eb, #3b82f6)'
        };
        
        // Different layout previews for each template
        let previewContent = '';
        
        switch(config.layout) {
            case 'single':
                previewContent = `
                    <div class="layout-demo single">
                        <div style="height: 30px; background: white; opacity: 0.3; margin-bottom: 10px;"></div>
                        <div style="height: 10px; background: white; opacity: 0.2; margin-bottom: 15px;"></div>
                        <div style="height: 10px; background: white; opacity: 0.2; margin-bottom: 15px;"></div>
                        <div style="height: 20px; background: white; opacity: 0.3; margin-bottom: 20px;"></div>
                        <div style="height: 10px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                        <div style="height: 10px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                    </div>
                `;
                break;
            case 'two-column':
                previewContent = `
                    <div class="layout-demo two-column">
                        <div style="background: white; opacity: 0.3; border-radius: 4px;">
                            ${config.hasPhoto ? '<div style="width: 60px; height: 60px; background: white; opacity: 0.4; margin: 10px auto; border-radius: 50%;"></div>' : ''}
                            <div style="height: 10px; background: white; opacity: 0.2; margin: 10px;"></div>
                            <div style="height: 10px; background: white; opacity: 0.2; margin: 10px;"></div>
                        </div>
                        <div>
                            <div style="height: 30px; background: white; opacity: 0.3; margin-bottom: 15px;"></div>
                            <div style="height: 15px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                            <div style="height: 15px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                        </div>
                    </div>
                `;
                break;
            case 'modern':
                previewContent = `
                    <div class="layout-demo modern">
                        ${config.hasPhoto ? '<div style="width: 80px; height: 80px; background: white; opacity: 0.4; border-radius: 50%; margin-bottom: 15px;"></div>' : ''}
                        <div style="height: 25px; background: white; opacity: 0.3; margin-bottom: 10px; width: 80%;"></div>
                        <div style="height: 15px; background: white; opacity: 0.2; margin-bottom: 5px; width: 60%;"></div>
                        <div style="height: 15px; background: white; opacity: 0.2; width: 70%;"></div>
                    </div>
                `;
                break;
            case 'creative':
                previewContent = `
                    <div class="layout-demo creative">
                        <div style="width: 100%; height: 30px; background: white; opacity: 0.3; margin-bottom: 15px; border-radius: 4px;"></div>
                        <div style="display: flex; gap: 10px; width: 100%;">
                            <div style="flex: 1; height: 100px; background: white; opacity: 0.2; border-radius: 4px;"></div>
                            <div style="flex: 2; height: 100px; background: white; opacity: 0.3; border-radius: 4px;"></div>
                        </div>
                    </div>
                `;
                break;
            case 'minimal':
                previewContent = `
                    <div class="layout-demo minimal">
                        <div style="height: 25px; background: white; opacity: 0.3; margin-bottom: 20px;"></div>
                        <div style="height: 2px; background: white; opacity: 0.3; margin-bottom: 15px;"></div>
                        <div style="height: 15px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                        <div style="height: 15px; background: white; opacity: 0.2; margin-bottom: 10px;"></div>
                    </div>
                `;
                break;
        }
        
        templateCard.innerHTML = `
            <div class="template-preview" style="background: ${gradientColors[id] || gradientColors['modern-pro']};">
                ${previewContent}
            </div>
            <div class="template-info">
                <h4><i class="fas fa-file-alt"></i> ${config.name}</h4>
                <p>${config.category.replace(/([A-Z])/g, ' $1').replace(/\b\w/g, l => l.toUpperCase())} template</p>
                <div class="template-stats">
                    <span><i class="fas fa-palette"></i> ${config.layout} Layout</span>
                    <span><i class="fas fa-camera"></i> ${config.hasPhoto ? 'With Photo' : 'No Photo'}</span>
                </div>
                <button class="btn btn-primary" data-template="${id}">
                    <i class="fas fa-check"></i> Use This Template
                </button>
            </div>
        `;
        
        templatesGrid.appendChild(templateCard);
    }
    
    // Add event listeners to template buttons
    document.querySelectorAll('[data-template]').forEach(button => {
        button.addEventListener('click', function() {
            const templateId = this.getAttribute('data-template');
            selectTemplate(templateId);
        });
    });
}

// ===== TEMPLATE SELECTION =====
function selectTemplate(templateId) {
    currentTemplate = templateId;
    const config = templateConfigs[templateId];
    
    if (config) {
        // Update form controls
        document.getElementById('templateSelect').value = templateId;
        document.getElementById('templateColor').value = config.color;
        document.getElementById('fontFamily').value = config.font;
        document.getElementById('layoutStyle').value = config.layout;
        document.getElementById('previewTemplate').textContent = config.name;
        
        // Show editor section
        document.getElementById('templates').style.display = 'none';
        document.getElementById('editor').style.display = 'block';
        
        // Scroll to editor
        document.getElementById('editor').scrollIntoView({ behavior: 'smooth' });
        
        // Show success message
        showToast(`"${config.name}" template selected. Start editing your resume!`);
        
        // Update preview
        updatePreview();
    }
}

// ===== INITIALIZE EDITOR =====
function initEditor() {
    // Image Upload
    const profileImageInput = document.getElementById('profileImage');
    const uploadImageBtn = document.getElementById('uploadImageBtn');
    const profileImagePreview = document.getElementById('profileImagePreview');
    
    uploadImageBtn.addEventListener('click', () => profileImageInput.click());
    
    profileImageInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            if (file.size > 2 * 1024 * 1024) {
                showToast('Image size should be less than 2MB', 'error');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(event) {
                resumeData.personal.profileImage = event.target.result;
                profileImagePreview.innerHTML = `<img src="${event.target.result}" alt="Profile">`;
                updatePreview();
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Form input listeners
    const formInputs = ['fullName', 'jobTitle', 'summary', 'email', 'phone', 'location', 'linkedin', 'skills', 'hobbies', 'languages'];
    
    formInputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('input', function() {
                resumeData.personal[id] = this.value;
                updateResumeData();
            });
        }
    });
    
    // Template change listener
    document.getElementById('templateSelect').addEventListener('change', function() {
        selectTemplate(this.value);
    });
    
    // Color change listener
    document.getElementById('templateColor').addEventListener('input', updatePreview);
    
    // Font change listener
    document.getElementById('fontFamily').addEventListener('change', updatePreview);
    
    // Layout change listener
    document.getElementById('layoutStyle').addEventListener('change', updatePreview);
    
    // Add experience button
    document.getElementById('addExperience').addEventListener('click', function() {
        const container = document.getElementById('experienceContainer');
        const item = document.createElement('div');
        item.className = 'experience-item';
        item.innerHTML = `
            <input type="text" class="form-control experience-title" placeholder="Job Title">
            <input type="text" class="form-control experience-company" placeholder="Company Name">
            <input type="text" class="form-control experience-location" placeholder="Location">
            <div class="form-row">
                <input type="month" class="form-control experience-start" placeholder="Start Date">
                <input type="month" class="form-control experience-end" placeholder="End Date">
            </div>
            <textarea class="form-control experience-description" placeholder="Responsibilities & Achievements" rows="2"></textarea>
            <button type="button" class="btn btn-small remove-item">
                <i class="fas fa-trash"></i> Remove
            </button>
        `;
        container.appendChild(item);
        
        // Add event listeners to new inputs
        item.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', updateResumeData);
        });
        
        // Add remove functionality
        item.querySelector('.remove-item').addEventListener('click', function() {
            container.removeChild(item);
            updateResumeData();
        });
    });
    
    // Add education button
    document.getElementById('addEducation').addEventListener('click', function() {
        const container = document.getElementById('educationContainer');
        const item = document.createElement('div');
        item.className = 'education-item';
        item.innerHTML = `
            <input type="text" class="form-control education-degree" placeholder="Degree">
            <input type="text" class="form-control education-school" placeholder="Institution">
            <input type="text" class="form-control education-location" placeholder="Location">
            <div class="form-row">
                <input type="month" class="form-control education-start" placeholder="Start Date">
                <input type="month" class="form-control education-end" placeholder="End Date">
            </div>
            <input type="text" class="form-control education-gpa" placeholder="GPA/CGPA (optional)">
            <button type="button" class="btn btn-small remove-item">
                <i class="fas fa-trash"></i> Remove
            </button>
        `;
        container.appendChild(item);
        
        // Add event listeners
        item.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', updateResumeData);
        });
        
        item.querySelector('.remove-item').addEventListener('click', function() {
            container.removeChild(item);
            updateResumeData();
        });
    });
    
    // Preview button
    document.getElementById('previewBtn').addEventListener('click', function() {
        document.getElementById('templates').style.display = 'none';
        document.getElementById('editor').style.display = 'block';
        document.getElementById('editor').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Back to templates button
    document.getElementById('backToTemplates').addEventListener('click', function() {
        document.getElementById('editor').style.display = 'none';
        document.getElementById('templates').style.display = 'block';
        document.getElementById('templates').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Download PDF button
    document.getElementById('downloadPdf').addEventListener('click', downloadPDF);
    
    // Download Word button
    document.getElementById('downloadDoc').addEventListener('click', downloadDOC);
}

// ===== UPDATE RESUME DATA =====
function updateResumeData() {
    // Update experience data
    resumeData.experience = [];
    document.querySelectorAll('.experience-item').forEach(item => {
        const startDate = item.querySelector('.experience-start')?.value;
        const endDate = item.querySelector('.experience-end')?.value;
        
        let dateDisplay = '';
        if (startDate) {
            const start = new Date(startDate);
            const startStr = start.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            if (endDate) {
                const end = new Date(endDate);
                const endStr = end.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                dateDisplay = `${startStr} - ${endStr}`;
            } else {
                dateDisplay = `${startStr} - Present`;
            }
        }
        
        const experience = {
            title: item.querySelector('.experience-title')?.value || '',
            company: item.querySelector('.experience-company')?.value || '',
            location: item.querySelector('.experience-location')?.value || '',
            startDate: startDate,
            endDate: endDate,
            dates: dateDisplay,
            description: item.querySelector('.experience-description')?.value || ''
        };
        if (experience.title || experience.company) {
            resumeData.experience.push(experience);
        }
    });
    
    // Update education data
    resumeData.education = [];
    document.querySelectorAll('.education-item').forEach(item => {
        const startDate = item.querySelector('.education-start')?.value;
        const endDate = item.querySelector('.education-end')?.value;
        
        let dateDisplay = '';
        if (startDate) {
            const start = new Date(startDate);
            const startStr = start.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            if (endDate) {
                const end = new Date(endDate);
                const endStr = end.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                dateDisplay = `${startStr} - ${endStr}`;
            } else {
                dateDisplay = `${startStr} - Present`;
            }
        }
        
        const education = {
            degree: item.querySelector('.education-degree')?.value || '',
            school: item.querySelector('.education-school')?.value || '',
            location: item.querySelector('.education-location')?.value || '',
            startDate: startDate,
            endDate: endDate,
            dates: dateDisplay,
            gpa: item.querySelector('.education-gpa')?.value || ''
        };
        if (education.degree || education.school) {
            resumeData.education.push(education);
        }
    });
    
    // Update skills
    const skillsInput = document.getElementById('skills');
    if (skillsInput) {
        resumeData.skills = skillsInput.value.split(',').map(skill => skill.trim()).filter(skill => skill);
    }
    
    // Update hobbies
    const hobbiesInput = document.getElementById('hobbies');
    if (hobbiesInput) {
        resumeData.hobbies = hobbiesInput.value.split(',').map(hobby => hobby.trim()).filter(hobby => hobby);
    }
    
    // Update languages
    const languagesInput = document.getElementById('languages');
    if (languagesInput) {
        resumeData.languages = languagesInput.value.split(',').map(lang => lang.trim()).filter(lang => lang);
    }
    
    updatePreview();
}

// ===== UPDATE PREVIEW =====
function updatePreview() {
    const previewContent = document.getElementById('previewContent');
    if (!previewContent) return;
    
    const config = templateConfigs[currentTemplate];
    const color = document.getElementById('templateColor').value;
    const font = document.getElementById('fontFamily').value;
    const layoutStyle = document.getElementById('layoutStyle').value;
    
    // Generate preview HTML based on template and layout
    let previewHTML = `
        <div class="resume-preview ${layoutStyle}-layout" style="font-family: ${font}; color: ${color};">
    `;
    
    // Header with/without photo
    if (config.hasPhoto && resumeData.personal.profileImage) {
        previewHTML += `
            <div class="resume-header with-photo">
                <img src="${resumeData.personal.profileImage}" class="profile-photo" alt="Profile">
                <div>
                    <h1 class="resume-name">${resumeData.personal.fullName || 'Your Name'}</h1>
                    <div class="resume-title">${resumeData.personal.jobTitle || 'Professional Title'}</div>
                    <div class="resume-contact">
                        ${resumeData.personal.email ? `<span><i class="fas fa-envelope"></i> ${resumeData.personal.email}</span>` : ''}
                        ${resumeData.personal.phone ? `<span><i class="fas fa-phone"></i> ${resumeData.personal.phone}</span>` : ''}
                        ${resumeData.personal.location ? `<span><i class="fas fa-map-marker-alt"></i> ${resumeData.personal.location}</span>` : ''}
                        ${resumeData.personal.linkedin ? `<span><i class="fab fa-linkedin"></i> ${resumeData.personal.linkedin}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    } else {
        previewHTML += `
            <div class="resume-header">
                <h1 class="resume-name">${resumeData.personal.fullName || 'Your Name'}</h1>
                <div class="resume-title">${resumeData.personal.jobTitle || 'Professional Title'}</div>
                <div class="resume-contact">
                    ${resumeData.personal.email ? `<span><i class="fas fa-envelope"></i> ${resumeData.personal.email}</span>` : ''}
                    ${resumeData.personal.phone ? `<span><i class="fas fa-phone"></i> ${resumeData.personal.phone}</span>` : ''}
                    ${resumeData.personal.location ? `<span><i class="fas fa-map-marker-alt"></i> ${resumeData.personal.location}</span>` : ''}
                    ${resumeData.personal.linkedin ? `<span><i class="fab fa-linkedin"></i> ${resumeData.personal.linkedin}</span>` : ''}
                </div>
            </div>
        `;
    }
    
    // Professional Summary
    if (resumeData.personal.summary) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">PROFESSIONAL SUMMARY</h3>
                <p>${resumeData.personal.summary}</p>
            </div>
        `;
    }
    
    // Work Experience
    if (resumeData.experience.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">WORK EXPERIENCE</h3>
                ${resumeData.experience.map(exp => `
                <div class="experience-item-preview">
                    <div class="item-header">
                        <div class="item-title">${exp.title}</div>
                        <div class="item-dates">${exp.dates}</div>
                    </div>
                    <div class="item-company">${exp.company}${exp.location ? ` • ${exp.location}` : ''}</div>
                    ${exp.description ? `<div class="item-description">${exp.description}</div>` : ''}
                </div>
                `).join('')}
            </div>
        `;
    }
    
    // Education
    if (resumeData.education.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">EDUCATION</h3>
                ${resumeData.education.map(edu => `
                <div class="education-item-preview">
                    <div class="item-header">
                        <div class="item-title">${edu.degree}</div>
                        <div class="item-dates">${edu.dates}</div>
                    </div>
                    <div class="item-school">${edu.school}${edu.location ? ` • ${edu.location}` : ''}</div>
                    ${edu.gpa ? `<div class="education-gpa">GPA: ${edu.gpa}</div>` : ''}
                </div>
                `).join('')}
            </div>
        `;
    }
    
    // Skills
    if (resumeData.skills.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">SKILLS</h3>
                <div class="skills-list">
                    ${resumeData.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                </div>
            </div>
        `;
    }
    
    // Languages
    if (resumeData.languages.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">LANGUAGES</h3>
                <div class="languages-list">
                    ${resumeData.languages.map(lang => {
                        const parts = lang.split(':');
                        if (parts.length === 2) {
                            return `<div class="language-item">
                                <span class="language-name">${parts[0].trim()}</span>
                                <span class="language-level">${parts[1].trim()}</span>
                            </div>`;
                        }
                        return `<div class="language-item">
                            <span class="language-name">${lang}</span>
                        </div>`;
                    }).join('')}
                </div>
            </div>
        `;
    }
    
    // Hobbies & Interests
    if (resumeData.hobbies.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <h3 class="section-title">HOBBIES & INTERESTS</h3>
                <div class="hobbies-list">
                    ${resumeData.hobbies.map(hobby => `<span class="hobby-tag">${hobby}</span>`).join('')}
                </div>
            </div>
        `;
    }
    
    previewHTML += `</div>`;
    
    previewContent.innerHTML = previewHTML;
    
    // Update word count
    const text = previewContent.textContent || '';
    const wordCount = text.split(/\s+/).filter(word => word.length > 0).length;
    document.getElementById('previewWords').textContent = `${wordCount} words`;
}

// ===== DOWNLOAD PDF =====
async function downloadPDF() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.style.display = 'flex';
    
    try {
        // Create a clone of the preview for PDF generation
        const previewContent = document.getElementById('previewContent');
        const pdfClone = previewContent.cloneNode(true);
        
        // Apply PDF-specific styles
        pdfClone.classList.add('pdf-resume');
        pdfClone.style.width = '210mm';
        pdfClone.style.minHeight = '297mm';
        pdfClone.style.padding = '25mm';
        pdfClone.style.margin = '0';
        pdfClone.style.boxSizing = 'border-box';
        pdfClone.style.background = 'white';
        pdfClone.style.fontSize = '12pt';
        
        // Set color from template
        const color = document.getElementById('templateColor').value;
        pdfClone.style.color = color;
        
        // Set font from template
        const font = document.getElementById('fontFamily').value;
        pdfClone.style.fontFamily = font;
        
        // Hide profile image for PDF to avoid CORS issues
        const profileImage = pdfClone.querySelector('.profile-photo');
        if (profileImage) {
            // Convert base64 image to data URL for PDF
            if (resumeData.personal.profileImage && resumeData.personal.profileImage.startsWith('data:image')) {
                // Keep the image if it's already a data URL
                profileImage.style.width = '80px';
                profileImage.style.height = '80px';
            } else {
                // Remove image if not a valid data URL
                profileImage.remove();
            }
        }
        
        // Create a container for the PDF
        const pdfContainer = document.createElement('div');
        pdfContainer.style.position = 'fixed';
        pdfContainer.style.left = '-9999px';
        pdfContainer.style.top = '0';
        pdfContainer.style.width = '210mm';
        pdfContainer.style.height = '297mm';
        pdfContainer.style.padding = '25mm';
        pdfContainer.style.margin = '0';
        pdfContainer.style.boxSizing = 'border-box';
        pdfContainer.style.background = 'white';
        pdfContainer.appendChild(pdfClone);
        document.body.appendChild(pdfContainer);
        
        // Wait for fonts and images to load
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Generate PDF
        const canvas = await html2canvas(pdfClone, {
            scale: 2,
            useCORS: true,
            logging: false,
            backgroundColor: '#ffffff',
            width: pdfClone.offsetWidth,
            height: pdfClone.offsetHeight,
            windowWidth: pdfClone.offsetWidth,
            windowHeight: pdfClone.offsetHeight
        });
        
        // Remove temporary container
        document.body.removeChild(pdfContainer);
        
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jspdf.jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: 'a4'
        });
        
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        
        // Calculate image dimensions to fit page
        const imgWidth = canvas.width;
        const imgHeight = canvas.height;
        const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
        const imgWidthFinal = imgWidth * ratio;
        const imgHeightFinal = imgHeight * ratio;
        
        // Center the image on the page
        const x = (pdfWidth - imgWidthFinal) / 2;
        const y = (pdfHeight - imgHeightFinal) / 2;
        
        pdf.addImage(imgData, 'PNG', x, y, imgWidthFinal, imgHeightFinal);
        pdf.save(`${resumeData.personal.fullName || 'resume'}.pdf`);
        
        showToast('PDF downloaded successfully!');
    } catch (error) {
        console.error('PDF generation error:', error);
        showToast('Error generating PDF. Please try again.', 'error');
    } finally {
        loadingOverlay.style.display = 'none';
    }
}

// ===== DOWNLOAD WORD DOC =====
async function downloadDOC() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    loadingOverlay.style.display = 'flex';
    
    try {
        const { Document, Paragraph, TextRun, HeadingLevel, Packer, AlignmentType } = window.docx;
        
        // Get template color for styling
        const color = document.getElementById('templateColor').value;
        const config = templateConfigs[currentTemplate];
        
        // Create document content with template styling
        const doc = new Document({
            styles: {
                paragraphStyles: [{
                    id: "Heading1",
                    name: "Heading 1",
                    basedOn: "Normal",
                    next: "Normal",
                    quickFormat: true,
                    run: {
                        size: 32,
                        bold: true,
                        color: color
                    },
                    paragraph: {
                        spacing: { after: 200 }
                    }
                }, {
                    id: "Heading2",
                    name: "Heading 2",
                    basedOn: "Normal",
                    next: "Normal",
                    quickFormat: true,
                    run: {
                        size: 24,
                        bold: true,
                        color: color
                    },
                    paragraph: {
                        spacing: { before: 200, after: 100 }
                    }
                }, {
                    id: "Heading3",
                    name: "Heading 3",
                    basedOn: "Normal",
                    next: "Normal",
                    quickFormat: true,
                    run: {
                        size: 20,
                        bold: true,
                        color: color
                    },
                    paragraph: {
                        spacing: { before: 150, after: 100 }
                    }
                }]
            },
            sections: [{
                properties: {
                    page: {
                        margin: {
                            top: 1000,
                            right: 1000,
                            bottom: 1000,
                            left: 1000
                        }
                    }
                },
                children: [
                    // Name and Title
                    new Paragraph({
                        children: [
                            new TextRun({
                                text: resumeData.personal.fullName || 'Your Name',
                                size: 32,
                                bold: true,
                                color: color
                            })
                        ],
                        alignment: AlignmentType.CENTER,
                        spacing: { after: 300 }
                    }),
                    
                    new Paragraph({
                        children: [
                            new TextRun({
                                text: resumeData.personal.jobTitle || 'Professional Title',
                                size: 24,
                                color: color
                            })
                        ],
                        alignment: AlignmentType.CENTER,
                        spacing: { after: 400 }
                    }),
                    
                    // Contact Information
                    new Paragraph({
                        children: [
                            ...(resumeData.personal.email ? [
                                new TextRun({
                                    text: `✉ ${resumeData.personal.email}`,
                                    size: 20
                                }),
                                new TextRun({
                                    text: '   ',
                                    size: 20
                                })
                            ] : []),
                            ...(resumeData.personal.phone ? [
                                new TextRun({
                                    text: `📱 ${resumeData.personal.phone}`,
                                    size: 20
                                }),
                                new TextRun({
                                    text: '   ',
                                    size: 20
                                })
                            ] : []),
                            ...(resumeData.personal.location ? [
                                new TextRun({
                                    text: `📍 ${resumeData.personal.location}`,
                                    size: 20
                                }),
                                new TextRun({
                                    text: '   ',
                                    size: 20
                                })
                            ] : []),
                            ...(resumeData.personal.linkedin ? [
                                new TextRun({
                                    text: `🔗 ${resumeData.personal.linkedin}`,
                                    size: 20
                                })
                            ] : [])
                        ],
                        alignment: AlignmentType.CENTER,
                        spacing: { after: 500 }
                    }),
                    
                    // Professional Summary
                    ...(resumeData.personal.summary ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'PROFESSIONAL SUMMARY',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        new Paragraph({
                            text: resumeData.personal.summary,
                            spacing: { after: 400 }
                        })
                    ] : []),
                    
                    // Work Experience
                    ...(resumeData.experience.length > 0 ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'WORK EXPERIENCE',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        ...resumeData.experience.flatMap(exp => [
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: exp.title,
                                        bold: true,
                                        size: 22
                                    })
                                ],
                                spacing: { after: 50 }
                            }),
                            
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: `${exp.company}${exp.location ? ` | ${exp.location}` : ''}`,
                                        italics: true,
                                        size: 20
                                    })
                                ],
                                spacing: { after: 50 }
                            }),
                            
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: exp.dates,
                                        size: 18,
                                        color: '666666'
                                    })
                                ],
                                spacing: { after: 50 }
                            }),
                            
                            ...(exp.description ? [
                                new Paragraph({
                                    text: exp.description,
                                    spacing: { after: 200 }
                                })
                            ] : [])
                        ])
                    ] : []),
                    
                    // Education
                    ...(resumeData.education.length > 0 ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'EDUCATION',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        ...resumeData.education.flatMap(edu => [
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: edu.degree,
                                        bold: true,
                                        size: 22
                                    })
                                ],
                                spacing: { after: 50 }
                            }),
                            
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: `${edu.school}${edu.location ? ` | ${edu.location}` : ''}`,
                                        italics: true,
                                        size: 20
                                    })
                                ],
                                spacing: { after: 50 }
                            }),
                            
                            new Paragraph({
                                children: [
                                    new TextRun({
                                        text: `${edu.dates}${edu.gpa ? ` | GPA: ${edu.gpa}` : ''}`,
                                        size: 18,
                                        color: '666666'
                                    })
                                ],
                                spacing: { after: 200 }
                            })
                        ])
                    ] : []),
                    
                    // Skills
                    ...(resumeData.skills.length > 0 ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'SKILLS',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        new Paragraph({
                            text: resumeData.skills.join(' • '),
                            spacing: { after: 400 }
                        })
                    ] : []),
                    
                    // Languages
                    ...(resumeData.languages.length > 0 ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'LANGUAGES',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        new Paragraph({
                            text: resumeData.languages.join(' • '),
                            spacing: { after: 400 }
                        })
                    ] : []),
                    
                    // Hobbies
                    ...(resumeData.hobbies.length > 0 ? [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'HOBBIES & INTERESTS',
                                    size: 24,
                                    bold: true,
                                    color: color
                                })
                            ],
                            spacing: { before: 200, after: 100 }
                        }),
                        
                        new Paragraph({
                            text: resumeData.hobbies.join(' • '),
                            spacing: { after: 200 }
                        })
                    ] : [])
                ]
            }]
        });
        
        // Generate and download
        const blob = await Packer.toBlob(doc);
        saveAs(blob, `${resumeData.personal.fullName || 'resume'}.docx`);
        
        showToast('Word document downloaded successfully!');
    } catch (error) {
        console.error('DOC generation error:', error);
        showToast('Error generating Word document. Please try again.', 'error');
    } finally {
        loadingOverlay.style.display = 'none';
    }
}

// ===== TEMPLATE FILTERING =====
function initTemplateFiltering() {
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const filterValue = this.getAttribute('data-filter');
            document.querySelectorAll('.template-card').forEach(card => {
                const cardFilters = card.getAttribute('data-filter');
                
                if (filterValue === 'all' || cardFilters.includes(filterValue)) {
                    card.style.display = 'block';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
}

// ===== UTILITY FUNCTIONS =====
function showToast(message, type = 'success') {
    const toast = document.getElementById('successToast');
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                      <span>${message}</span>`;
    toast.style.background = type === 'success' ? '#10b981' : '#ef4444';
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// ===== FORMAT DATE =====
function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

// ===== INITIALIZE APPLICATION =====
document.addEventListener('DOMContentLoaded', function() {
    generateTemplates();
    initTemplateFiltering();
    initEditor();
    
    // Initialize with sample data
    setTimeout(() => {
        document.getElementById('fullName').value = 'Alex Johnson';
        document.getElementById('jobTitle').value = 'Software Engineer';
        document.getElementById('summary').value = 'Passionate software engineer with 5+ years of experience building scalable web applications. Specialized in JavaScript, React, and Node.js.';
        document.getElementById('email').value = 'alex.johnson@example.com';
        document.getElementById('phone').value = '(123) 456-7890';
        document.getElementById('location').value = 'San Francisco, CA';
        document.getElementById('skills').value = 'JavaScript, React, Node.js, Python, AWS, Git, Agile Methodologies';
        document.getElementById('hobbies').value = 'Photography, Hiking, Reading, Chess';
        document.getElementById('languages').value = 'English: Native, Spanish: Intermediate, French: Beginner';
        
        // Add sample experience
        const expContainer = document.getElementById('experienceContainer');
        expContainer.innerHTML = `
            <div class="experience-item">
                <input type="text" class="form-control experience-title" placeholder="Job Title" value="Senior Software Engineer">
                <input type="text" class="form-control experience-company" placeholder="Company Name" value="TechCorp Inc">
                <input type="text" class="form-control experience-location" placeholder="Location" value="San Francisco, CA">
                <div class="form-row">
                    <input type="month" class="form-control experience-start" placeholder="Start Date" value="2020-01">
                    <input type="month" class="form-control experience-end" placeholder="End Date" value="2023-12">
                </div>
                <textarea class="form-control experience-description" placeholder="Responsibilities & Achievements" rows="2">Led a team of 5 developers to build a scalable microservices architecture. Improved application performance by 40%.</textarea>
                <button type="button" class="btn btn-small remove-item">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        `;
        
        // Add sample education
        const eduContainer = document.getElementById('educationContainer');
        eduContainer.innerHTML = `
            <div class="education-item">
                <input type="text" class="form-control education-degree" placeholder="Degree" value="Bachelor of Science in Computer Science">
                <input type="text" class="form-control education-school" placeholder="Institution" value="Stanford University">
                <input type="text" class="form-control education-location" placeholder="Location" value="Stanford, CA">
                <div class="form-row">
                    <input type="month" class="form-control education-start" placeholder="Start Date" value="2016-08">
                    <input type="month" class="form-control education-end" placeholder="End Date" value="2020-05">
                </div>
                <input type="text" class="form-control education-gpa" placeholder="GPA/CGPA (optional)" value="3.8/4.0">
                <button type="button" class="btn btn-small remove-item">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        `;
        
        // Trigger input events to update data
        ['fullName', 'jobTitle', 'summary', 'email', 'phone', 'location', 'skills', 'hobbies', 'languages'].forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.dispatchEvent(new Event('input'));
            }
        });
        
        // Add event listeners to sample items
        expContainer.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('input', updateResumeData);
        });
        
        expContainer.querySelector('.remove-item').addEventListener('click', function() {
            expContainer.removeChild(expContainer.querySelector('.experience-item'));
            updateResumeData();
        });
        
        eduContainer.querySelectorAll('input').forEach(input => {
            input.addEventListener('input', updateResumeData);
        });
        
        eduContainer.querySelector('.remove-item').addEventListener('click', function() {
            eduContainer.removeChild(eduContainer.querySelector('.education-item'));
            updateResumeData();
        });
        
        // Update resume data
        updateResumeData();
    }, 1000);
});